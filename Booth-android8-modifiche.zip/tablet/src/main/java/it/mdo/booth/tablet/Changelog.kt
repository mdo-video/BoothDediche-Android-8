package it.mdo.booth.tablet

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.ViewGroup
import android.view.Window
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Novità di ogni versione. Si mostrano dopo un aggiornamento e dalle impostazioni (voce "Novità"). */
object Changelog {
    private class Entry(val code: Int, val name: String, val title: String, val lines: List<String>)

    // dal più recente al più vecchio; code = appVersionCode
    private val entries = listOf(
        Entry(70, "1.65", "Compatibile con Android 8", listOf(
            "Il tablet ora si installa anche su Android 8 e 9 (prima serviva Android 10)",
            "Su Android 8-10 la dashcam registra con la sola fotocamera frontale: la posteriore insieme alla frontale richiede Android 11 o più recente",
        )),
        Entry(68, "1.63", "Telecomando dall'app Controllo", listOf(
            "Il tablet accetta i gesti del telecomando anche dall'app Controllo (nuova scheda Telecomando): stesse azioni del telecomando fisico",
        )),
        Entry(67, "1.62", "Anteprime verticali e orientamento automatico", listOf(
            "Anteprime che rispettano il formato: video e foto orizzontali restano orizzontali, quelli verticali restano verticali, anche mischiati nella stessa colonna",
            "Ultime dediche ridisegnate: miniature con angoli morbidi e ombra, numero e ora in basso, ▶ per i video e fotocamera per le foto; la dedica aperta ha il contorno oro e fucsia",
            "Video verticale: più dediche in \"Ultime\" (fino a 3 colonne, in base allo spazio libero a sinistra dell'anteprima)",
            "Video verticale: la barra del volume resta verticale, centrata tra le due icone in alto e il 60 e 90 del selettore, e va dalle icone fino al selettore",
            "Video orizzontale: la barra del volume resta a metà tra il bordo destro dell'anteprima e il bordo destro dello schermo",
            "Orientamento video: nuovo tasto Automatico, il telefono camera segue la sua posizione (verticale o orizzontale)",
        )),
        Entry(66, "1.61", "Telecomando programmabile", listOf(
            "Telecomando: 1 clic = scatta o registra secondo la modalità scelta (foto o video), 2 clic = passa da foto a video e viceversa, pressione lunga = torcia in video / flash in foto",
            "Combinazioni programmabili: da Impostazioni → Telecomando (tablet) e dall'app Controllo puoi assegnare a 1, 2, 3, 4 clic e pressione lunga: scatta, foto↔video, torcia/flash, durata video e altro",
            "Dopo lo scatto con il telecomando collegato i tasti mostrano i clic: Salva (1), Rifai (2), Condividi (3)",
            "Chiuso il QR, o salvata la dedica, si torna da soli a Pronto: tolta la schermata di conferma con Nuova/Condividi",
            "Legenda del telecomando sopra al volume del microfono e sempre leggibile; ora mostra le combinazioni scelte",
            "Il selettore della durata del video è allineato ai tasti REC e luce",
        )),
        Entry(65, "1.60", "Avvisi sempre leggibili", listOf(
            "Gli avvisi in alto (telecomando collegato/scollegato, flash, torcia) ora stanno sopra a tutto, anche sopra il messaggio di benvenuto, con sfondo pieno, bordo spesso e scritta più grande",
        )),
        Entry(64, "1.59", "Messaggio di benvenuto che non copre più nulla", listOf(
            "Il messaggio di benvenuto sta su una riga tra l'anteprima e i tasti in alto a destra; se è lungo si rimpicciolisce da solo invece di coprire la scritta degli effetti e i tasti",
            "Con gli altri bordi, un messaggio molto lungo va a capo senza uscire dallo schermo",
        )),
        Entry(63, "1.58", "Bordo in mezzo tra scritta e puntini", listOf(
            "Effetti: la scritta \"Scorri per gli effetti\" sta sopra il bordo bianco del fotogramma e i puntini sotto, a pari distanza: il bordo è esattamente nel mezzo",
        )),
        Entry(62, "1.57", "Scritta effetti più leggibile", listOf(
            "La scritta \"Scorri per gli effetti\" sul bordo ha lo sfondo scuro pieno: il bordo del fotogramma non la attraversa più",
        )),
        Entry(61, "1.56", "Splash con scritta tradotta", listOf(
            "Splash: sotto l'immagine compare \"Tocca per iniziare\" come testo, quindi cambia con la lingua dell'app (Tap to start in inglese)",
            "L'immagine della splash non deve più contenere la scritta",
        )),
        Entry(60, "1.55", "Scritta effetti sul bordo", listOf(
            "La scritta \"Scorri per gli effetti\" ora sta a cavallo del bordo del fotogramma e i puntini degli effetti subito sotto, dentro l'anteprima",
        )),
        Entry(56, "1.51", "Filtri AR sul volto", listOf(
            "Tablet: nella fila degli effetti trovi anche i filtri AR",
            "Nuovi filtri AR: Corona, Occhiali, Baffi, Coniglietto e Cuori. Seguono il volto (anche inclinato) e funzionano con più persone",
            "Si vedono dal vivo nell'anteprima e finiscono in foto e video. Il video si elabora a fine ripresa, come per cornice ed effetti",
            "Per mostrarli agli ospiti: Impostazioni, Effetti, tocca quelli che vuoi (massimo 7 in tutto)",
        )),
        Entry(54, "1.49", "Novità sempre giuste", listOf(
            "Dopo un aggiornamento le novità mostrano ora la versione giusta, e anche quelle che ti eri perso",
        )),
        Entry(53, "1.48", "Scelta degli effetti e editor a cursori", listOf(
            "Impostazioni, Effetti: nuova griglia con tutti gli effetti e la loro anteprima dal vivo; tocchi quelli da mostrare agli ospiti (massimo 7)",
            "Nuovo editor a cursori per creare i tuoi effetti (colori vivi, rosso, verde, blu, luminosità) con anteprima, senza scrivere testo",
            "I tuoi effetti già creati restano e si possono modificare o eliminare",
        )),
        Entry(51, "1.46", "Codice di abbinamento e ritorno veloce", listOf(
            "Dopo Salva, con il QR spento, si torna subito alla schermata Pronto: la dedica resta salvata",
            "Impostazioni, Telefono camera: nuovo campo per il codice di abbinamento del telefono camera",
            "Il QR degli ospiti ora contiene una firma: ogni ospite apre solo la propria dedica",
            "Controllo, Diretta booth: manda al telefono di controllo anche il volume del microfono",
        )),
        Entry(50, "1.45", "App Camera nello stile di Controllo", listOf(
            "Camera: nuova schermata scura a schede, uguale all'app Controllo, sviluppata in orizzontale su due colonne (in verticale diventa una colonna)",
            "Camera: stato grande (Pronto, In registrazione, In attesa del tablet), pallino del collegamento al tablet e tempo di registrazione con barra",
            "Camera: qualità, orientamento e microfono sempre visibili; tasti Controlla, Novità e Schermo nero",
        )),
        Entry(49, "1.44", "Menu Dediche in ordine", listOf(
            "Controllo, scheda Dediche: i tasti sotto le miniature vanno a capo in righe ordinate e \"Elimina\" non si schiaccia più in verticale",
            "Controllo, scheda Dediche: anche i tasti in alto (Aggiorna, Nuove, Seleziona tutto, Nessuna, IP) si vedono tutti, senza scorrere",
        )),
        Entry(48, "1.43", "Dirette, impostazioni a schede e slider nuovo", listOf(
            "Tablet: la scritta \"Scorri per gli effetti\" resta sempre visibile",
            "Tablet: slider della durata più moderno, senza sfondo; valori sopra la barra e \"Durata massima\" sotto",
            "Tablet: impostazioni divise per categorie (Telefono camera, Aspetto, Ospiti, Accessori, Dashcam, Sistema), come nell'app Controllo",
            "Controllo: nuova \"Diretta booth\" a bassa risoluzione (max 640x480, 15 fotogrammi al secondo); la vecchia Diretta ora si chiama \"Diretta dashcam\"",
            "Controllo: schede riordinate: Stato, Dediche, Diretta booth, Diretta dashcam, Video, Log, Impost.",
        )),
        Entry(47, "1.42", "Slider durata più piccolo", listOf(
            "Lo slider della durata è più compatto e non copre più il tasto torcia/flash",
        )),
        Entry(46, "1.41", "Durata scelta dall'ospite", listOf(
            "Sul tablet, in basso a destra, l'ospite sceglie la durata del video con uno slider: 30, 60, 90 o 120 secondi",
        )),
        Entry(45, "1.40", "Volume e durata", listOf(
            "Barra del volume più a sinistra, a metà tra l'anteprima e il bordo, e il doppio più spessa",
            "Scala in dB reali: in basso -60 dB, in alto 0 dB; tacche a -18 dB (giallo) e -6 dB (rosso)",
            "Microfono USB di nuovo rilevato: la barra lo segue anche se lo colleghi dopo l'avvio",
            "Durata massima con uno slider: 30, 60, 90 o 120 secondi",
        )),
        Entry(44, "1.39", "Volume microfono", listOf(
            "La barra del volume funziona anche prima di premere REC",
            "Barra più stabile: il rumore di fondo del silenzio non la muove più",
        )),
        Entry(43, "1.38", "Eventi, volume e dediche", listOf(
            "Barra del volume del microfono sul tablet mentre registri un video",
            "Pellicola del tablet: solo l'evento in corso; prima del collegamento niente tasto REC",
            "Impostazioni tablet: Elimina tutte (evento in corso) con conferma",
            "Controllo: tocco = anteprima, tocco lungo = selezione, Seleziona tutto, Elimina, Nuovo evento con data",
        )),
        Entry(42, "1.37", "Pagina QR", listOf(
            "Sotto il tasto Scarica c'è un suggerimento per condividere il file",
        )),
        Entry(41, "1.36", "Telecomando e pagina QR", listOf(
            "Il telecomando durante il conto alla rovescia non fa nulla, come il tocco sul tablet",
            "Il QR apre una pagina con anteprima e tasto Scarica per foto e video",
        )),
        Entry(40, "1.35", "Effetti migliori e splash", listOf(
            "Effetti ridotti a 7, i migliori: Normale, Cinema, Dorato, Romantico, Noir, Vintage, Neon",
            "I puntini sono sempre 7 e corrispondono uno a uno agli effetti",
            "Quando scorri, il nome dell'effetto compare al centro e poi sparisce",
            "Nuova splash: dalle impostazioni (SPLASH INIZIALE) scegli un PNG o JPG; si vede all'apertura e riappare dopo il tempo di inattività che scegli",
            "Galleria nelle impostazioni del tablet: tocchi una dedica per nasconderla o mostrarla nella pellicola",
            "Dediche nascoste: da Controllo le togli solo dalla pellicola, restano sul telefono camera",
        )),
        Entry(37, "1.32", "Telecomando e effetti sul bordo", listOf(
            "Torcia e flash hanno lo stesso fulmine",
            "Il pallino in alto a destra è il telecomando: verde solo se collegato, rosso altrimenti; toccalo per vedere la legenda",
            "Messaggio animato quando il telecomando si collega o si scollega",
            "Effetti: solo puntini sul bordo in alto; la scritta \"scorri\" sparisce dopo la scelta. Si scorre in verticale o in orizzontale",
        )),
        Entry(36, "1.31", "Nuovi effetti e tasto torcia/flash", listOf(
            "Il tasto accanto a REC è la torcia quando sei in VIDEO e il flash quando sei in FOTO (giallo = acceso)",
            "Tanti nuovi effetti: Cinema, Dorato, Romantico, Pastello, Noir, Sbiadito e quelli simpatici (Neon, Cartoon, Anni '80, Sogno, Notte, Pop Art, Sole, Gelato, Tramonto, Oceano, Matrix, Alieno)",
            "Effetti personalizzati: nelle impostazioni, campo \"Effetti personalizzati\" (si incolla un testo, c'è un esempio). Il tablet li manda in automatico al telefono",
        )),
        Entry(35, "1.30", "Nuovo layout come il mockup", listOf(
            "Pallino di stato del telefono accanto al Wi-Fi, in alto a destra",
            "Effetti: puntini, scritta \"Scorri per gli effetti\" e nome dell'effetto sempre visibile",
            "Tasto flash giallo accanto a REC (giallo = acceso)",
            "Dopo il video: scheda al centro con Salva grande, poi Rifai e Condividi",
            "Nello storico il video più recente ha il bordo giallo",
        )),
        Entry(34, "1.29", "Nuove icone", listOf(
            "Icone rinnovate: stesso logo MD, colore diverso per ogni app (Booth rosso, Camera blu, Controllo verde)",
        )),
        Entry(33, "1.28", "Schermata più pulita", listOf(
            "Nascosti per gli ospiti batteria, spazio e stato del telecomando: restano Wi-Fi/QR, Torcia, Flash, Video/Foto e REC",
        )),
        Entry(32, "1.27", "Solo i tasti per gli ospiti", listOf(
            "Tolti i tasti Cornice e Blocca dalla schermata principale: restano Torcia e Flash. Cornice e blocco si cambiano da impostazioni o da Controllo",
        )),
        Entry(31, "1.26", "Impostazioni nascoste", listOf(
            "Il pulsante Impostazioni non si vede più: si aprono tenendo premuto sul bordo fuori dall'anteprima (poi il PIN)",
        )),
        Entry(30, "1.25", "Effetti a scorrimento verticale", listOf(
            "Gli effetti si cambiano scorrendo il dito in su e in giù sull'anteprima: l'indicazione sta sul lato sinistro, senza coprire la cornice",
        )),
        Entry(28, "1.23", "Nuovo layout e effetti a scorrimento", listOf(
            "Schermata principale rifatta: pellicola a sinistra, titolo e pulsanti in alto, tasti Torcia, Flash, Cornice e Blocca a destra, interruttore Video/Foto accanto a REC",
            "Gli effetti si cambiano scorrendo il dito sull'anteprima, come le storie di Instagram, con una piccola indicazione",
            "Impostazioni: ora è un pulsante in alto a destra (chiede il PIN)",
        )),
        Entry(27, "1.22", "Effetti, inglese e ritorno automatico", listOf(
            "Effetti stile Instagram su foto e video (B&N, Seppia, Vintage, Caldo, Freddo, Vivido): gli ospiti li scelgono dalla fila sotto l'anteprima e li vedono subito",
            "Testi per gli ospiti anche in inglese: impostazioni, Lingua per gli ospiti",
            "Ritorno automatico: il QR si chiude dopo 45 secondi e un video non salvato si salva da solo dopo 60 secondi",
            "Il tasto QR in alto a destra ora ha l'icona del Wi-Fi",
        )),
        Entry(26, "1.21", "Notifiche di aggiornamento ad app chiusa", listOf(
            "Il controllo delle nuove versioni ora funziona anche quando l'app è chiusa (ogni 3 ore circa, anche dopo il riavvio)",
            "Se non arriva nulla, nelle impostazioni Android dell'app togli le restrizioni batteria (su Xiaomi anche \"Avvio automatico\")",
        )),
        Entry(25, "1.20", "Sblocco remoto", listOf(
            "Dall'app Controllo: Impostazioni, Sblocca il tablet. Sul tablet si aprono le impostazioni senza digitare il codice",
            "Lo sblocco remoto si vede nel registro eventi",
            "PIN a scelta: la prima volta che tocchi l'ingranaggio il tablet ti fa scegliere un PIN da 4 a 6 cifre (o nessun PIN). Si cambia o si toglie dalle impostazioni, voce PIN DEL TABLET",
        )),
        Entry(24, "1.19", "Booth a prova di ospite", listOf(
            "Condividi apre solo il QR (salva il video se serve): non si esce più dal kiosk",
            "Dopo il video: Rifai, Salva, Condividi. Dopo il salvataggio: Nuova, Condividi",
            "Nello storico: Chiudi e Condividi. Eliminare i video si può solo dall'app Controllo",
            "Ingranaggio nascosto: impostazioni con pressione lunga in alto a destra e codice a 6 cifre",
            "Tolti CORNICE e AUTO/FISSO dal tablet (restano nelle impostazioni e in Controllo)",
            "Notifica dashcam sincera: dice \"Registrazione in corso\" solo se registra davvero, altrimenti \"Dashcam ferma\" con il motivo; con la dashcam spenta non c'è notifica",
        )),
        Entry(23, "1.18", "Nuovo look e aggiornamenti pronti", listOf(
            "Aggiornamenti scaricati da soli in background: arriva la notifica \"Aggiornamento pronto\" e basta toccare Installa",
            "Scheda del telecomando ridisegnata, con stato collegato e azioni ben leggibili",
            "Novità di ogni versione dentro l'app (questa schermata)",
        )),
        Entry(22, "1.17", "Notifica di aggiornamento", listOf(
            "Notifica quando esce una nuova versione, in tutte e tre le app",
            "Controllo automatico ogni 6 ore",
        )),
        Entry(21, "1.16", "Legenda del telecomando", listOf(
            "La legenda non copre più i tasti torcia, flash e cornice",
            "Testo completo, senza tagli",
        )),
        Entry(20, "1.15", "Interfaccia identica al mockup", listOf(
            "Font Poppins, icone nuove, miniature dello storico 16:9 con titolo ULTIMI",
            "Tasti scuri viola semitrasparenti; bordo Fucsia predefinito (tablet)",
        )),
        Entry(19, "1.14", "Interfaccia tablet ridisegnata", listOf(
            "Con il bordo Largo tutto sta fuori dall'immagine: REC e FOTO in basso, tasti grandi a destra, storico a sinistra",
            "Batteria e spazio più grandi, rossi quando stanno finendo",
        )),
        Entry(18, "1.13", "Bordo colorato attorno all'anteprima", listOf(
            "Impostazioni › Bordo anteprima: Pieno schermo, Sottile o Largo",
            "Sette colori predefiniti o codice #RRGGBB",
        )),
        Entry(17, "1.12", "Tab Dediche in Booth Controllo", listOf(
            "Miniature di video e foto salvati sul telefono camera",
            "Scarica in Galleria le dediche scelte",
        )),
        Entry(16, "1.11", "Telecomando Bluetooth a un tasto", listOf(
            "1 pressione REC, 2 FOTO, 3 flash, lunga o 4 torcia",
            "Con l'anteprima: 1 Salva, 2 Rifai",
            "Icona del telecomando con anello verde/rosso e legenda dei gesti",
        )),
        Entry(15, "1.10", "Schermo nero sul telefono camera", listOf(
            "Dopo 60 secondi resta solo un puntino di funzionamento, a luminosità minima",
            "Doppio tocco per uscire",
        )),
        Entry(14, "1.9", "Sicurezza con l'accelerometro", listOf(
            "Il tablet rileva cadute, urti e spostamenti e protegge i video per 24 ore",
            "Il telefono camera avvisa il tablet se viene spostato o cade",
        )),
        Entry(13, "1.8", "Diretta e controllo remoto", listOf(
            "Tab Diretta: la fotocamera frontale del tablet in tempo reale",
            "Le impostazioni del tablet si cambiano dall'app Controllo",
        )),
        Entry(12, "1.7", "Dashcam, controllo remoto, log, aggiornamenti", listOf(
            "Dashcam sul tablet a segmenti, con sovrascrittura dei più vecchi",
            "App Booth Controllo con stato, log eventi e video",
            "Aggiornamenti dalle release GitHub",
        )),
        Entry(11, "1.6", "Cornice e flash", listOf(
            "Cornice PNG su foto e video",
            "Flash nelle foto e tasti rapidi flash e cornice sul tablet",
        )),
    )

    private fun dp(a: Activity, v: Int): Int = (v * a.resources.displayMetrics.density).toInt()

    /** dopo un aggiornamento mostra le novità dell'ultima versione, una volta sola */
    fun showIfNew(a: Activity, installedCode: Int) {
        val prefs = a.getSharedPreferences("changelog", Context.MODE_PRIVATE)
        val seen = prefs.getInt("seen", 0)
        if (seen >= installedCode) return
        prefs.edit().putInt("seen", installedCode).apply()
        // prima installazione: solo l'ultima novità; dopo un aggiornamento: tutte quelle che mancavano (al massimo 3)
        val news = if (seen == 0) {
            entries.filter { it.code <= installedCode }.take(1)
        } else {
            entries.filter { it.code in (seen + 1)..installedCode }.take(3)
        }
        if (news.isEmpty()) return
        show(a, news)
    }

    /** storico completo */
    fun show(a: Activity) = show(a, entries)

    private fun show(a: Activity, list: List<Entry>) {
        try {
            val d = Dialog(a)
            d.requestWindowFeature(Window.FEATURE_NO_TITLE)
            val root = LinearLayout(a).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(a, 26), dp(a, 24), dp(a, 26), dp(a, 20))
                background = GradientDrawable().apply {
                    setColor(Color.parseColor("#1D1026"))
                    cornerRadius = dp(a, 28).toFloat()
                    setStroke(dp(a, 2), Color.parseColor("#5A2F73"))
                }
            }
            root.addView(TextView(a).apply {
                text = "NOVITÀ"
                setTextColor(Color.parseColor("#FF2BFF"))
                textSize = 13f
                typeface = Typeface.DEFAULT_BOLD
                letterSpacing = 0.1f
            })
            val body = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
            for (e in list) {
                body.addView(TextView(a).apply {
                    text = "Versione ${e.name} · ${e.title}"
                    setTextColor(Color.WHITE)
                    textSize = 18f
                    typeface = Typeface.DEFAULT_BOLD
                    setPadding(0, dp(a, 14), 0, dp(a, 4))
                })
                for (l in e.lines) {
                    body.addView(TextView(a).apply {
                        text = "•  $l"
                        setTextColor(Color.parseColor("#E8D6F5"))
                        textSize = 15f
                        setLineSpacing(0f, 1.15f)
                        setPadding(0, dp(a, 2), 0, dp(a, 2))
                    })
                }
            }
            val sv = ScrollView(a).apply { addView(body) }
            val maxH = (a.resources.displayMetrics.heightPixels * 0.55f).toInt()
            root.addView(sv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            sv.post {
                if (sv.height > maxH) {
                    val lp = sv.layoutParams
                    lp.height = maxH
                    sv.layoutParams = lp
                }
            }
            val btn = Button(a).apply {
                text = "Chiudi"
                isAllCaps = false
                setTextColor(Color.parseColor("#14101A"))
                typeface = Typeface.DEFAULT_BOLD
                textSize = 16f
                background = GradientDrawable().apply {
                    setColor(Color.parseColor("#FFE83A"))
                    cornerRadius = dp(a, 26).toFloat()
                }
                setOnClickListener { d.dismiss() }
            }
            val blp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(a, 52))
            blp.topMargin = dp(a, 16)
            root.addView(btn, blp)
            d.setContentView(root)
            d.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            d.show()
            val w = minOf((a.resources.displayMetrics.widthPixels * 0.9f).toInt(), dp(a, 560))
            d.window?.setLayout(w, ViewGroup.LayoutParams.WRAP_CONTENT)
            d.window?.setGravity(Gravity.CENTER)
        } catch (e: Exception) {
        }
    }
}
